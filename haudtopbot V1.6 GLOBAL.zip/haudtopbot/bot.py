import csv
import json
import os
import time
import logging
import aiosqlite
from aiogram import Bot, Dispatcher, types, executor
import datetime
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, InputFile, ContentType
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from dotenv import load_dotenv
import asyncio
import sys
import nest_asyncio
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.dispatcher.filters import Text, ContentTypeFilter, Command
import subprocess
from aiogram.utils.callback_data import CallbackData
import aiogram
import re
from aiogram.utils.exceptions import BadRequest
from typing import List
from collections import defaultdict
    
subprocess.run(["clear"])
nest_asyncio.apply()
load_dotenv(".env")

TOKEN, HAUDERS, ORG, CLANS, DATA_DIR, PLAYERS_JSON, ORG_JSON, LOGS_DIR, LOG_DB, DB_PATH, USER_IDS_FILE, ADMIN_IDS, CHANNEL_ID = (
    os.getenv("BOT_TOKEN"),
    "hauders.csv",
    "organizations.csv",
    "clans.csv",
    "data",
    os.path.join("data", "hauders.json"),
    os.path.join("data", "orgs.json"),
    "Logs",
    "base.db",
    "data/pinned.db",
    "data/user_ids.txt",
    [5396017152],
    "@HaudDriblingChannel"
)

bot = Bot(token=TOKEN, parse_mode='HTML')
dp = Dispatcher(bot, storage=MemoryStorage())
subscribe_cb = CallbackData("subscribe", "user_id")
media_groups = defaultdict(list)

class AdminStates(StatesGroup):
    waiting_for_user_id = State()
    waiting_for_user_idun = State()
    waiting_for_block_time = State()
    WAITING_FOR_DECLINE_REASON = State()

class Form(StatesGroup):
    awaiting_rassilka = State()

class ApplicationStates(StatesGroup):
    waiting_for_acceptance = State()

class ApplicationStates(StatesGroup):
    WAITING_FOR_APPLICATION = State()

RANK_EMOJIS = {
    "E": "🔴", "D": "🟠", "C": "🟡", "B": "🟢", "A": "🔵", "S": "🟣", "S+": "⚪️", "Elite": "⚫️"
}

log_folder = os.path.join(LOGS_DIR, str(time.localtime().tm_year))
os.makedirs(log_folder, exist_ok=True)

log_filename = time.strftime("%d-%m-%Y-%H-%M-%S") + ".txt"
log_filepath = os.path.join(log_folder, log_filename)

logging.basicConfig(
    filename=log_filepath,
    level=logging.INFO,
    format='%(asctime)s - %(message)s'
)

logging.info("Бот запущен.")
print("Бот запущен.")

async def init_db():
    async with aiosqlite.connect(LOG_DB) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                started INTEGER,
                status INTEGER DEFAULT 0,
                blocked_until INTEGER DEFAULT 0
            )
        """)
        await db.commit()

async def init_pinned():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS pinners (
                user_id INTEGER PRIMARY KEY,
                pinned_message_id INTEGER
            )
        """)
        await db.commit()

async def register_user(user_id: int):
    try:
        async with aiosqlite.connect(LOG_DB) as db:
            cursor = await db.execute("SELECT user_id FROM users WHERE user_id = ?", (user_id,))
            existing_user = await cursor.fetchone()
            
            if existing_user:
                logging.info(f"Пользователь с id {user_id} уже существует.")
                return
            
            cursor = await db.execute("SELECT COUNT(*) FROM users")
            count = (await cursor.fetchone())[0] + 1
            
            await db.execute(
                "INSERT INTO users (user_id, started, status, blocked_until) VALUES (?, ?, 0, 0)",
                (user_id, count)
            )
            await db.commit()
            logging.info(f"Зарегистрирован новый пользователь: {user_id}, это {count}-й пользователь.")  
    except Exception as e:
        logging.error(f"Ошибка при регистрации пользователя {user_id}: {e}")

async def save_user_id(user_id: int):
    if not os.path.exists(os.path.dirname(USER_IDS_FILE)):
        os.makedirs(os.path.dirname(USER_IDS_FILE))

    if os.path.exists(USER_IDS_FILE):
        with open(USER_IDS_FILE, "r") as f:
            existing_user_ids = f.read().splitlines()
    else:
        existing_user_ids = []
        
    if str(user_id) not in existing_user_ids:
        with open(USER_IDS_FILE, "a") as f:
            f.write(f"{user_id}\n")
            existing_user_ids.clear()
            return

async def load_user_ids():
    if not os.path.exists(USER_IDS_FILE):
        return []
    with open(USER_IDS_FILE, "r") as f:
        return [line.strip() for line in f.readlines()]

async def is_admin(user_id: int) -> bool:
    return user_id == 5396017152

async def check_subscription(user_id: int) -> bool:
    member = await bot.get_chat_member(CHANNEL_ID, user_id)
    return member.status in ["member", "administrator", "creator"]

async def get_pinned_message_id(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT pinned_message_id FROM pinners WHERE user_id = ?", (user_id,)) as cursor:
            row = await cursor.fetchone()
            return row[0] if row else None

async def save_pinned_message_id(user_id: int, message_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("INSERT INTO pinners (user_id, pinned_message_id) VALUES (?, ?) ON CONFLICT(user_id) DO UPDATE SET pinned_message_id = ?",
                         (user_id, message_id, message_id))
        await db.commit()

@dp.message_handler(commands=['start'])
async def start(message: types.Message):
    user_id = message.from_user.id
    zakreptext = "⚠️ <b>Если бот не отвечает на нажатия кнопок, на команды, на действия — нажмите</b> /start<b>. Это решает все проблемы. Скоро эта проблема будет исправлена.</b>\n\n<blockquote>#Важное</blockquote>"
    pinned_message_id = await get_pinned_message_id(user_id)
    if not pinned_message_id:
        zakrep = await bot.send_message(user_id, zakreptext, parse_mode="HTML")
        await bot.pin_chat_message(user_id, zakrep.message_id)
        await save_pinned_message_id(user_id, zakrep.message_id)
        
    if not await check_subscription(user_id):
        keyboard = InlineKeyboardMarkup().add(
            InlineKeyboardButton("✔️ Подписаться", url=f"https://t.me/{CHANNEL_ID.lstrip('@')}"),
            InlineKeyboardButton("✅️ Я подписался", callback_data="subscribed")
        )
        await message.answer(
            "<i><b>⚠️ Извините, но обязательным условием бота является подписка на наш новостной канал. "
            "Вы не подписаны на канал — </b>@HaudDriblingChannel<b>. "
            "После подписки, нажмите на кнопку, чтобы использовать бота.</b></i>",
            reply_markup=keyboard
        )
        return
    
    await register_user(user_id)
    await save_user_id(user_id)

    async with aiosqlite.connect(LOG_DB) as db:
        cursor = await db.execute("SELECT status, blocked_until FROM users WHERE user_id = ?", (user_id,))
        result = await cursor.fetchone()
        if result:
            status, blocked_until = result
            if status == 1:
                if blocked_until > time.time():
                    ban_time = datetime.datetime.fromtimestamp(blocked_until).strftime("%Y-%m-%d %H:%M:%S")
                    await message.answer(f"🚫 Вы заблокированы до {ban_time}.")
                    return

    keyboard = InlineKeyboardMarkup().add(
        InlineKeyboardButton("👤 Хаудфайтеры", callback_data="players"),
        InlineKeyboardButton("👥️ Организации", callback_data="organizations"),
        InlineKeyboardButton("👾 Кланы", callback_data="clans"),
        InlineKeyboardButton("ℹ Больше", callback_data="more_info")
    )
    sticker_id = "CAACAgQAAxkBAAIB4GfJTnf31XMgw4RWBCmxb9-U2Lb9AAK7FAACsPixUrHpDFjG3ml2NgQ"
    await message.answer_sticker(sticker_id)
    await message.answer("<i><b>👋 Здраствуйте.\n\n👾Я — Ваш Бот Топ-Помощник в Хаудинг Комьюнити. Здесь Вы Можете посмотреть топы всех известных (и не очень) Хаудфайтеров, которые являются в этой деятельности Мастерами! Если Ты хочешь попасть в топ — Подавай заявку Администратору, подробнее — по кнопке «ℹ️ Больше». Не нравится как разместили в топе? Подавай заявку Администратору, он её рассмотрит, и возможно (❗️) примет меры!</b></i>\n\n<blockquote><b>Наш новостной канал:</b> @HaudDriblingChannel<b>.</b></blockquote>")
    await message.answer("🔅 <b>Выберите категорию:</b>", reply_markup=keyboard)

@dp.callback_query_handler(lambda c: c.data.startswith("subscribed"))
async def check_subscription_callback(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    if await check_subscription(user_id):
        await callback.message.edit_text(
            "<i><b>✅️ Вы подписались на наш новостной канал, спасибо за поддержку! "
            "Для продолжения — нажмите </b></i>/start."
        )
    else:
        await callback.answer("❌ Вы не подписаны на канал! Попробуйте снова.", show_alert=True)

async def safe_edit_text(message: types.Message, text: str, reply_markup: InlineKeyboardMarkup):
    if message.text != text:
        await message.edit_text(text, reply_markup=reply_markup)

@dp.callback_query_handler(lambda c: c.data == "players")
async def show_players_menu(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    if not await check_subscription(user_id):
        keyboard = InlineKeyboardMarkup().add(
            InlineKeyboardButton("✔️ Подписаться", url=f"https://t.me/{CHANNEL_ID.lstrip('@')}"),
            InlineKeyboardButton("✅️ Я подписался", callback_data="subscribed")
        )
        await callback.message.edit_text(
            "<i><b>⚠️ Извините, но обязательным условием бота является подписка на наш новостной канал. "
            "Вы не подписаны на канал — </b>@HaudDriblingChannel<b>. "
            "После подписки, нажмите на кнопку, чтобы использовать бота.</b></i>",
            reply_markup=keyboard
        )
        return

    players = load_players()
    keyboard = InlineKeyboardMarkup()

    for rank in players.keys():
        emoji = RANK_EMOJIS.get(rank, "")
        keyboard.add(InlineKeyboardButton(f"{emoji} Хаудфайтеры класса {rank}", callback_data=f"rankplayers_{rank}"))

    keyboard.add(InlineKeyboardButton("⬅ Назад", callback_data="back"))
    await safe_edit_text(callback.message, "⚜️ <b>Выберите ранг:</b>", keyboard)

@dp.callback_query_handler(lambda c: c.data.startswith("rankplayers_"))
async def show_players_by_rank(callback: types.CallbackQuery):
    rank = callback.data.split("_")[1]
    players = load_players().get(rank, [])
    emoji = RANK_EMOJIS.get(rank, "")
    if players:
        text = f"<blockquote><b>{emoji} Хаудфайтеры класса {rank}:</b></blockquote>\n" + "\n".join(f"{i+1}. {player}" for i, player in enumerate(players))
    else:
        text = "🚫 <b>Нет хаудфайтеров в этом классе.</b>"
    text += "\n\n<blockquote><b>❗️Нумерация — это не обозначение Хаудфайтера в топе класса, это просто нумерация, но в скором времени планируется доработка, следите за официальным источником.</b></blockquote>"

    keyboard = InlineKeyboardMarkup().add(InlineKeyboardButton("⬅ Назад", callback_data="players"))
    await callback.message.edit_text(text, reply_markup=keyboard)
    
@dp.callback_query_handler(lambda c: c.data == "organizations")
async def show_orgs_menu(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    if not await check_subscription(user_id):
        keyboard = InlineKeyboardMarkup().add(
            InlineKeyboardButton("✔️ Подписаться", url=f"https://t.me/{CHANNEL_ID.lstrip('@')}"),
            InlineKeyboardButton("✅️ Я подписался", callback_data="subscribed")
        )
        await callback.message.edit_text(
            "<i><b>⚠️ Извините, но обязательным условием бота является подписка на наш новостной канал. "
            "Вы не подписаны на канал — </b>@HaudDriblingChannel<b>. "
            "После подписки, нажмите на кнопку, чтобы использовать бота.</b></i>",
            reply_markup=keyboard
        )
        return
    
    orgs = load_orgs()
    keyboard = InlineKeyboardMarkup()

    for rank, organizations in orgs.items():
        emoji = RANK_EMOJIS.get(rank, "")
        keyboard.add(InlineKeyboardButton(f"{emoji} Организации класса {rank}", callback_data=f"rankorg_{rank}"))

    keyboard.add(InlineKeyboardButton("⬅ Назад", callback_data="back"))
    await safe_edit_text(callback.message, "⚜️ <b>Выберите ранг:</b>", keyboard)

@dp.callback_query_handler(lambda c: c.data.startswith("rankorg_"))
async def show_players_by_rank(callback: types.CallbackQuery):
    rank = callback.data.split("_")[1]
    orgs = load_orgs().get(rank, [])
    emoji = RANK_EMOJIS.get(rank, "")

    if orgs:
        text = f"<blockquote><b>{emoji} Организации класса {rank}:</b></blockquote>\n" + \
               "\n".join(f"{i+1}. {org}" for i, org in enumerate(orgs))
    else:
        text = "🚫 <b>Нет организаций в этом классе.</b>"

    text += ("\n\n<blockquote><b>❗️Нумерация — это не обозначение Организации в топе класса, это просто нумерация, но в скором времени планируется доработка, следите за официальным источником.</b></blockquote>")

    keyboard = InlineKeyboardMarkup().add(InlineKeyboardButton("⬅ Назад", callback_data="organizations"))
    await callback.message.edit_text(text, reply_markup=keyboard)

@dp.callback_query_handler(lambda c: c.data == "more_info", state="*")
async def more_info(callback: types.CallbackQuery, state: FSMContext):
    await callback.answer()
    await state.finish()
    python_version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    aiogram_version = aiogram.__version__
    aiosqlite_version = aiosqlite.__version__

    text = (f"<i><b>Функция «🔷️ Подать заявку», которая подаёт заявку напрямую через бот, на данный момент находится на стадии тестирования, но уже готова к использованию. Вы Можете попробывать использовать её, но если у Вас возникнут ошибки с подачей заявки — Обращайтесь к </b></i>@Kiyatsuka.\n\n<blockquote><b>💠 Следите за официальными обновлениями тут —</b> @HaudDriblingChannel<b>.</b></blockquote>\n\n"
            f"<blockquote><b>Version: v1.6 GLOBAL</b></blockquote>\n"
            f"<blockquote><b>[Python|{python_version}+Aiogram|{aiogram_version}+Aiosqlite|{aiosqlite_version}]</b></blockquote>")

    keyboard = InlineKeyboardMarkup()
    keyboard.add(InlineKeyboardButton("🔷️ Подать заявку", callback_data="apply_request"))
    keyboard.add(InlineKeyboardButton("⬅ Назад", callback_data="back"))
    
    await callback.message.edit_text(text, reply_markup=keyboard)

@dp.callback_query_handler(lambda c: c.data == "apply_request")
async def apply_request(callback: types.CallbackQuery, state: FSMContext):
    await callback.answer()
    await state.finish()

    rules_text = ("⚠️ <b>Правила подачи заявки на добавление в Топ, чтобы её одобрили:\nПРИ Подаче заявки, Вы заполняете анкету [требование спец. Формата отключено.):\n\n<blockquote><b>1. Ваш Нейм в Хаудинге.\n2. Максимально отписанный обьем слов.\n3. Доказательства этого обьема (ссылки на посты, ссылки на сообщения, другие доказательства).\n4. Ваша основная каста в Хаудинге.\n5. Указывать Юзернейм и Айди, другие контактные данные необязательно, это за вас передаёт бот.\n6. Несоответствие формату заявки, неполные данные — отклонение заявки.</b>\n7. <i><b>⚠️ Спам заявками, флуд, липовые данные в заявке, любой другой саботаж — неаппелируемый БАН в проекте на срок по усмотрению Администратора.</b></i></blockquote>\n\n🔰 При нажатии инлайн-кнопки «✅️ Согласиться и Продолжить», вы автоматически соглашаетесь с этими правилами.</b>")
    
    keyboard = InlineKeyboardMarkup()
    keyboard.add(InlineKeyboardButton("✅ Согласиться и Продолжить", callback_data="accept_rules"))
    keyboard.add(InlineKeyboardButton("🔙 Назад", callback_data="more_info"))
    
    await callback.message.edit_text(rules_text, reply_markup=keyboard, parse_mode="HTML")

@dp.callback_query_handler(lambda c: c.data == "back_to_rules", state="*")
async def back_to_rules(callback: types.CallbackQuery, state: FSMContext):
    await callback.answer()
    await state.finish()
    rules_text = ("⚠️ <b>Правила подачи заявки на добавление в Топ, чтобы её одобрили:\nПРИ Подаче заявки, Вы заполняете анкету [требование спец. Формата отключено.):\n\n<blockquote><b>1. Ваш Нейм в Хаудинге.\n2. Максимально отписанный обьем слов.\n3. Доказательства этого обьема (ссылки на посты, ссылки на сообщения, другие доказательства).\n4. Ваша основная каста в Хаудинге.\n5. Указывать Юзернейм и Айди, другие контактные данные необязательно, это за вас передаёт бот.\n6. Несоответствие формату заявки, неполные данные — отклонение заявки.</b>\n7. <i><b>⚠️ Спам заявками, флуд, липовые данные в заявке, любой другой саботаж — неаппелируемый БАН в проекте на срок по усмотрению Администратора.</b></i></blockquote>\n\n🔰 При нажатии инлайн-кнопки «✅️ Согласиться и Продолжить», вы автоматически соглашаетесь с этими правилами.</b>")
    
    keyboard = InlineKeyboardMarkup()
    keyboard.add(InlineKeyboardButton("✅ Согласиться и Продолжить", callback_data="accept_rules"))
    keyboard.add(InlineKeyboardButton("🔙 Назад", callback_data="more_info"))
    
    await callback.message.edit_text(rules_text, reply_markup=keyboard)

@dp.callback_query_handler(lambda c: c.data == "accept_rules", state="*")
async def accept_rules(callback: types.CallbackQuery, state: FSMContext):
    await callback.answer()
    await ApplicationStates.WAITING_FOR_APPLICATION.set()
    
    keyboard = InlineKeyboardMarkup()
    keyboard.add(InlineKeyboardButton("🔙 Назад", callback_data="back_to_rules"))
    
    message_application = await callback.message.edit_text(
        "📤 <i><b>Отправьте вашу заявку. Вы можете прикрепить:\n- Текст\n- Фото/Видео\n- Документы\n- Голосовые сообщения\n- Стикеры\n- И другие медиаматериалы.</b></i>",
        reply_markup=keyboard,
        parse_mode="HTML"
    )
    
    await state.update_data(
        instruction_message_id=message_application.message_id,
        instruction_chat_id=message_application.chat.id
    )

@dp.message_handler(state=ApplicationStates.WAITING_FOR_APPLICATION, content_types=ContentType.ANY)
async def process_application(message: types.Message, state: FSMContext):
    try:
        if message.media_group_id:
            media_groups[message.media_group_id].append(message)
            await asyncio.sleep(1.5)
            
            if message.media_group_id not in media_groups:
                return

            album = media_groups.pop(message.media_group_id)
            await process_media_group(album, state)
            return
            
        await process_single_message(message, state)

    except Exception as e:
        logging.error(f"Application processing error: {str(e)}")
        await message.answer("❌ <b>Произошла ошибка при обработке заявки. Администраторы оповещены.</b>")
        await state.finish()

async def process_media_group(album: list, state: FSMContext):
    message = album[0]
    user = message.from_user
    admin_id = "5396017152"
    media_group = []
    
    username = f"@{user.username}" if user.username else user.full_name.lstrip("@")
    profile_link = f"\n<b>📎Ссылка на профиль: </b>tg://openmessage?user_id={user.id}\n<b>❌️ Без юзернейма.</b>" if not user.username else ""
    caption = f"🚨 <i><b>Новая заявка (медиа-группа)</b></i>!\n\n<i><b>👤Пользователь:</b></i> {username}{profile_link}\n<i><b>🆔 ID:</b></i> <code>{user.id}</code><i><b>\n📝 Сообщение:</b></i>"
    
    if album[0].caption:
        caption += f"\n{album[0].caption}"

    for index, msg in enumerate(album):
        media = None
        if msg.photo:
            media = types.InputMediaPhoto(msg.photo[-1].file_id)
        elif msg.video:
            media = types.InputMediaVideo(msg.video.file_id)
        elif msg.document:
            media = types.InputMediaDocument(msg.document.file_id)
        elif msg.audio:
            media = types.InputMediaAudio(msg.audio.file_id)
        elif msg.voice:
            media = types.InputMediaAudio(msg.voice.file_id)
        
        if media:
            if index == 0:
                media.caption = caption
                media.parse_mode = "HTML"
            media_group.append(media)

    try:
        await bot.send_media_group(admin_id, media_group)
        keyboard_admin = create_admin_keyboard(user.id)
        await bot.send_message(admin_id, "👾 <i><b>Действия по заявке:</b></i>", reply_markup=keyboard_admin)
    except Exception as e:
        await message.answer("❌ <b>Ошибка отправки медиа-группы! Администрация оповещена.</b>")
        logging.error(f"Media group error: {e}")
        return

    await handle_application_completion(message, state)

def create_admin_keyboard(user_id: int) -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup()
    keyboard.add(InlineKeyboardButton("✅️ Принять заявку", callback_data=f"yesq_{user_id}"))
    keyboard.add(InlineKeyboardButton("❌️ Отклонить заявку", callback_data=f"declinedq_{user_id}"))
    return keyboard

async def process_single_message(message: types.Message, state: FSMContext):
    user = message.from_user
    admin_id = "5396017152"
    keyboard_admin = create_admin_keyboard(user.id)
    
    username = f"@{user.username}" if user.username else user.full_name.lstrip("@")
    profile_link = f"\n<b>📎Ссылка на профиль: </b>tg://openmessage?user_id={user.id}\n<b>❌️ Без юзернейма.</b>" if not user.username else ""
    
    base_caption = f"🚨 <i><b>Новая заявка!\n\n👤Пользователь:</b></i> {username}{profile_link}\n<i><b>🆔 ID:</b></i> <code>{user.id}</code>"

    try:
        if message.content_type == ContentType.TEXT:
            full_caption = f"{base_caption}\n📝 <i><b>Сообщение:</b></i>\n{message.text}"
            await bot.send_message(admin_id, full_caption, reply_markup=keyboard_admin, parse_mode="HTML")
        
        else:
            caption_parts = [base_caption]
            
            if message.caption and message.content_type != ContentType.VIDEO_NOTE:
                caption_parts.append(f"📝 <i><b>Подпись:</b></i>\n{message.caption}")
            
            full_caption = "\n\n".join(caption_parts)
            
            if message.content_type == ContentType.STICKER:
                await bot.send_sticker(admin_id, message.sticker.file_id)
                await bot.send_message(admin_id, full_caption, reply_markup=keyboard_admin, parse_mode="HTML")
            
            elif message.content_type == ContentType.VIDEO_NOTE:
                await bot.send_video_note(admin_id, message.video_note.file_id)
                await bot.send_message(admin_id, full_caption, reply_markup=keyboard_admin, parse_mode="HTML")
            
            elif message.content_type == ContentType.ANIMATION:
                await bot.send_document(
                    admin_id,
                    message.animation.file_id,
                    caption=full_caption,
                    parse_mode="HTML"
                )
                await bot.send_message(admin_id, "👾 <i><b>Действия по заявке:</b></i>", reply_markup=keyboard_admin)
            
            else:
                media = create_media_object(message, full_caption)
                if media:
                    await bot.send_media_group(admin_id, [media])
                    await bot.send_message(admin_id, "👾 <i><b>Действия по заявке:</b></i>", reply_markup=keyboard_admin)

    except Exception as e:
        await message.answer("❌ <b>Ошибка отправки медиафайлов! Администрация оповещена.</b>")
        logging.error(f"Ошибка (line 485): {str(e)}")
        return

    await handle_application_completion(message, state)

def create_media_object(message: types.Message, caption: str):
    try:
        if message.content_type == ContentType.PHOTO:
            return types.InputMediaPhoto(message.photo[-1].file_id, caption=caption, parse_mode="HTML")
        elif message.content_type == ContentType.VIDEO:
            return types.InputMediaVideo(message.video.file_id, caption=caption, parse_mode="HTML")
        elif message.content_type == ContentType.DOCUMENT:
            return types.InputMediaDocument(message.document.file_id, caption=caption, parse_mode="HTML")
        elif message.content_type == ContentType.AUDIO:
            return types.InputMediaAudio(message.audio.file_id, caption=caption, parse_mode="HTML")
        elif message.content_type == ContentType.VOICE:
            return types.InputMediaAudio(message.voice.file_id, caption=caption, parse_mode="HTML")
        return None
    except Exception as e:
        logging.error(f"Ошибка создания медиа (line 504): {str(e)}")
        return None

async def handle_application_completion(message: types.Message, state: FSMContext):
    data = await state.get_data()
    message_id = data.get('instruction_message_id')
    chat_id = data.get('instruction_chat_id')

    keyboard = InlineKeyboardMarkup()
    keyboard.add(InlineKeyboardButton("❌️ Закрыть", callback_data="close_message"))
    
    new_text = "✔️ <b>Вы подали заявку. Чтобы вернуться к меню, используйте /start.</b>"
    
    try:
        if message_id and chat_id:
            await bot.edit_message_text(
                chat_id=chat_id,
                message_id=message_id,
                text=new_text,
                reply_markup=keyboard,
                parse_mode="HTML"
            )
        else:
            await message.answer(new_text, reply_markup=keyboard, parse_mode="HTML")
    except Exception as e:
        logging.error(f"Error editing message: {str(e)}")
    
    await state.finish()

@dp.callback_query_handler(lambda c: c.data.startswith("declinedq_"))
async def handle_declineq(callback: types.CallbackQuery, state: FSMContext):
    try:
        user_id = int(callback.data.split("_")[1])
        data = await state.get_data()
        
        original_content = callback.message.text or callback.message.caption or ""
        
        await state.update_data(
            user_id=user_id,
            content_type=data.get("application_content", "text"),
            original_message_id=callback.message.message_id,
            original_chat_id=callback.message.chat.id,
            original_content=original_content,
            app_message_id=data.get("instruction_message_id"),
            app_chat_id=data.get("instruction_chat_id")
        )
        
        keyboard = InlineKeyboardMarkup().add(
            InlineKeyboardButton("🔙 Назад", callback_data="decline_back")
        )
        await callback.message.edit_text(
            "📝 <i><b>Укажите причину отклонения:</b></i>",
            reply_markup=keyboard,
            parse_mode="HTML"
        )
        await AdminStates.WAITING_FOR_DECLINE_REASON.set()
        await callback.answer()
        
    except Exception as e:
        logging.error(f"Decline error (line 563): {e}")
        await callback.answer("❌ <b>Ошибка при обработке. Администрация оповещена.</b>")

@dp.callback_query_handler(lambda c: c.data == "decline_back", state=AdminStates.WAITING_FOR_DECLINE_REASON)
async def handle_decline_back(callback: types.CallbackQuery, state: FSMContext):
    data = await state.get_data()
    try:
        keyboard = InlineKeyboardMarkup()
        keyboard.add(InlineKeyboardButton(
            "✅️ Принять заявку", 
            callback_data=f"yesq_{data['user_id']}"
        ))
        keyboard.add(InlineKeyboardButton(
            "❌️ Отклонить заявку", 
            callback_data=f"declinedq_{data['user_id']}"
        ))

        if data.get('content_type', 'text') != 'text':
            await callback.message.edit_reply_markup(reply_markup=keyboard)
        else:
            await bot.edit_message_text(
                chat_id=data['original_chat_id'],
                message_id=data['original_message_id'],
                text=data.get('original_content', ''),
                reply_markup=keyboard,
                parse_mode="HTML"
            )

    except BadRequest:
        await callback.answer("❌ <b>Невозможно восстановить медиа-заявку.</b>", show_alert=True)
    except Exception as e:
        logging.error(f"Ошибка восстановления (line 594): {str(e)}")
        await callback.answer("❌ </i></b>Ошибка восстановления.</b></i>", show_alert=True)
    finally:
        await state.finish()
    
@dp.callback_query_handler(lambda c: c.data == "close_message", state="*")
async def handle_close_button(callback: types.CallbackQuery, state: FSMContext):
    try:
        await callback.message.delete()
        await state.finish()
    except Exception as e:
        print("Возникла критическая ошибка при удалении сообщения. Подробности в логах бота")
        logging.error(f"Ошибка при удалении сообщения (line 606): {e}")
    await callback.answer()

@dp.callback_query_handler(lambda c: c.data.startswith("yesq_"))
async def handle_acceptq(callback: types.CallbackQuery):
    try:
        user_id = int(callback.data.split("_")[1])
        await bot.send_message(user_id, "<i><b>👋 Здраствуйте. Администрация Бота рассмотрела Вашу заявку на добавление Вас в Топ Нашего Бота. Мы рады вам сообщить, что она была «✅️ Одобрена».\n\nВ скором времени Мы добавим Вас в один из классов топа, ожидайте. 🤗 Заранее спасибо за проявленное терпение.</b></i>")
        await callback.answer("✅️ Заявка принята.")
        await callback.message.edit_text(
            f"✅ <i><b>Заявка пользователя ID:</b></i> {user_id} <i><b>принята. Пользователь оповещён.</b></i>",
            reply_markup=None
        )
        
    except Exception as e:
        logging.error(f"Accept error (line 621): {str(e)}")
        await callback.answer("❌ Ошибка при обработке. Подробнее в логах.")

@dp.message_handler(state=AdminStates.WAITING_FOR_DECLINE_REASON, content_types=ContentType.TEXT)
async def process_decline_reason(message: types.Message, state: FSMContext):
    data = await state.get_data()
    try:
        if 'user_id' not in data or 'original_chat_id' not in data or 'original_message_id' not in data:
            raise KeyError(f"Missing keys: {[k for k in ['user_id', 'original_chat_id', 'original_message_id'] if k not in data]}")

        await bot.send_message(
            data['user_id'],
            f"👋 <i><b>Здраствуйте. Администрация Бота рассмотрела Вашу заявку на добавление Вас в Топ Нашего Бота. К сожалению, 🚫 Ваша заявка отклонена по причине:\n</b></i>{message.text}"
        )
        
        decline_text = "<b>❌️ Заявка отклонена. Пользователь был уведомлён.</b>"
        await bot.edit_message_text(
            chat_id=data['original_chat_id'],
            message_id=data['original_message_id'],
            text=decline_text,
            reply_markup=None,
            parse_mode="HTML"
        )
        
        await message.answer("ℹ️ <b>Причина отклонения отправлена пользователю.</b>")

        app_data = {
            'application_message_id': data.get('app_message_id'),
            'application_chat_id': data.get('app_chat_id')
        }
        
        if all(app_data.values()):
            try:
                await bot.edit_message_text(
                    chat_id=app_data['application_chat_id'],
                    message_id=app_data['application_message_id'],
                    text="🚫 <b>Ваша заявка была отклонена администратором.</b>")
            except Exception as edit_error:
                logging.error(f"Ошибка редактирования сообщения пользователя (line 659): {edit_error}")

    except Exception as e:
        logging.error(f"Decline reason error (line 662): {str(e)}")
        await message.answer("❌ <b>Не удалось обработать отклонение. Подробнее в логах.</b>")
    finally:
        await state.finish()
        
@dp.callback_query_handler(lambda c: c.data == "back")
async def back_to_main(callback: types.CallbackQuery):
    keyboard = InlineKeyboardMarkup()
    keyboard.add(InlineKeyboardButton("👤 Хаудфайтеры", callback_data="players"))
    keyboard.add(InlineKeyboardButton("👥️ Организации", callback_data="organizations"))
    keyboard.add(InlineKeyboardButton("👾 Кланы", callback_data="clans"))
    keyboard.add(InlineKeyboardButton("ℹ Больше", callback_data="more_info"))
    await callback.message.edit_text("🔅 <b>Выберите категорию:</b>", reply_markup=keyboard)

@dp.callback_query_handler(lambda c: c.data in ["clans"])
async def unavailable_feature(callback: types.CallbackQuery):
    await callback.answer("🔜 Эта опция в разработке.", show_alert=True)

def load_players():
    if not os.path.exists(DATA_DIR):
        os.makedirs(DATA_DIR)
    csv_mtime = os.path.getmtime(HAUDERS)
    players = {}
    if os.path.exists(PLAYERS_JSON):
        json_mtime = os.path.getmtime(PLAYERS_JSON)
        if csv_mtime > json_mtime:
            players = _load_players_from_csv()
            _save_players_to_json(players)
        else:
            with open(PLAYERS_JSON, "r", encoding="utf-8") as file:
                players = json.load(file)
    else:
        players = _load_players_from_csv()
        _save_players_to_json(players)

    return players

def _load_players_from_csv():
    players = {}
    with open(HAUDERS, "r", encoding="utf-8") as file:
        reader = csv.reader(file, delimiter=';')
        ranks = next(reader)
        names = next(reader)
        for rank, name_list in zip(ranks, names):
            players[rank] = name_list.split(", ") if name_list else []
    return players

def _save_players_to_json(players):
    with open(PLAYERS_JSON, "w", encoding="utf-8") as file:
        json.dump(players, file, ensure_ascii=False, indent=4)

def load_orgs():
    if not os.path.exists(DATA_DIR):
        os.makedirs(DATA_DIR)
    csv_mtime = os.path.getmtime(ORG)
    orgs = {}
    if os.path.exists(ORG_JSON):
        json_mtime = os.path.getmtime(ORG_JSON)
        if csv_mtime > json_mtime:
            orgs = _load_org_from_csv()
            _save_org_to_json(orgs)
        else:
            with open(ORG_JSON, "r", encoding="utf-8") as file:
                orgs = json.load(file)
    else:
        orgs = _load_org_from_csv()
        _save_org_to_json(orgs)

    return orgs

def _load_org_from_csv():
    orgs = {}
    with open(ORG, "r", encoding="utf-8") as file:
        reader = csv.reader(file, delimiter=';')
        ranks = next(reader)
        names = next(reader)
        for rank, name_list in zip(ranks, names):
            orgs[rank] = name_list.split(", ") if name_list else []
    return orgs

def _save_org_to_json(orgs):
    with open(ORG_JSON, "w", encoding="utf-8") as file:
        json.dump(orgs, file, ensure_ascii=False, indent=4)

@dp.message_handler(commands=['admin'])
async def admin_panel(message: types.Message):
    user_id = message.from_user.id
    if not await is_admin(user_id):
        pass
        return

    keyboard = InlineKeyboardMarkup()
    keyboard.add(InlineKeyboardButton("💬 Сообщение", callback_data="send_message"))
    keyboard.add(InlineKeyboardButton("🚫 Заблокировать Пользователя", callback_data="block_user"))
    keyboard.add(InlineKeyboardButton("⭕️ Разблокировать Пользователя", callback_data="unblock_user"))
    keyboard.add(InlineKeyboardButton("👑 Список Администраторов", callback_data="view_admins"))
    keyboard.add(InlineKeyboardButton("ℹ️ Статистика", callback_data="statistics"))
    keyboard.add(InlineKeyboardButton("❌️ Закрыть панель", callback_data="close_admin_panel"))

    await message.answer("🔰 <b>Панель Администратора. Выберите одну из кнопок навигации:</b>", reply_markup=keyboard)

@dp.callback_query_handler(lambda c: c.data == "close_admin_panel")
async def close_panel_admin(callback: types.CallbackQuery):
    await callback.message.delete()

@dp.callback_query_handler(lambda c: c.data == 'block_user')
async def block_user(callback: types.CallbackQuery):
    keyboard = InlineKeyboardMarkup()
    keyboard.add(InlineKeyboardButton("❌ Отменить", callback_data="cancel_block"))
    await callback.message.answer("🔰 <i><b>Пожалуйста, введите ID пользователя и время блокировки через пробел для блокировки:</b></i>", reply_markup=keyboard)
    await AdminStates.waiting_for_user_id.set()

@dp.message_handler(state=AdminStates.waiting_for_user_id)
async def block_user_by_id(message: types.Message, state: FSMContext):
    try:
        user_input = message.text.split()

        if len(user_input) < 2:
            await message.answer("❌ <b>Пожалуйста, укажите время блокировки в секундах.</b> <b>[Пример: 1234567890 99].</b>")
            await state.finish()
            return
        
        user_id, block_time_str = user_input

        user_id = int(user_id)
        block_time = int(block_time_str)

        if user_id in ADMIN_IDS:
            await message.answer("❌ <i><b>Невозможно заблокировать администратора.</b></i>")
            await state.finish()
            return

        async with aiosqlite.connect(LOG_DB) as db:
            cursor = await db.execute("SELECT user_id FROM users WHERE user_id = ?", (user_id,))
            if not await cursor.fetchone():
                await db.execute("INSERT INTO users (user_id, started, status, blocked_until) VALUES (?, 0, 0, 0)", (user_id,))
            
            blocked_until = time.time() + block_time
            await db.execute("UPDATE users SET status = 1, blocked_until = ? WHERE user_id = ?", (blocked_until, user_id))
            await db.commit()

        ban_time = datetime.datetime.fromtimestamp(blocked_until).strftime("%Y-%m-%d %H:%M:%S")
        await message.answer(f"🚫 <i><b>Пользователь с ID</b></i> <code>{user_id}</code> <i><b>заблокирован до {ban_time}.</b></i>")
        await bot.send_message(user_id, f"⚠️ <i>Здраствуйте. Администраторами бота было принято решение о <b>блокировке Вашего аккаунта до {ban_time}</b> за саботаж, спам, флуд или иные действия, которые Мы Считаем нарушающими Наши правила. <b>Решение на данный момент неоспоримо.</b></i>")
        await state.finish()
        return
        
    except ValueError:
        await message.answer("❌ <b>Неверный формат. Убедитесь, что ввели ID и время в секундах через пробел.</b> <b>[Пример: 1234567890 99].</b>")
        await state.finish()
        return

@dp.callback_query_handler(lambda c: c.data == "unblock_user")
async def unblock_user(callback: types.CallbackQuery):
    keyboard = InlineKeyboardMarkup()
    keyboard.add(InlineKeyboardButton("❌ Отменить", callback_data="cancel_unblock"))
    await callback.message.answer("🔰 <i><b>Пожалуйста, введите ID пользователя для разблокировки:</b></i>", reply_markup=keyboard)
    await AdminStates.waiting_for_user_idun.set()

@dp.message_handler(state=AdminStates.waiting_for_user_idun)
async def unblock_user_by_id(message: types.Message, state: FSMContext):
    user_id = message.text
    try:
        user_id = int(user_id)

        if user_id in ADMIN_IDS:
            await message.answer("❌ <i><b>Невозможно разблокировать администратора.</b></i>")
            await state.finish()
            return

        async with aiosqlite.connect(LOG_DB) as db:
            await db.execute("UPDATE users SET status = 0, blocked_until = 0 WHERE user_id = ?", (user_id,))
            await db.commit()
        
        await message.answer(f"✅ <i><b>Пользователь с ID</b></i> <code>{user_id}</code> <i><b>был разблокирован.</b></i>")
        await bot.send_message(user_id, f"⚠️ <i>Здраствуйте. Администраторами бота было принято решение о <b>разблокировке Вашего аккаунта.</b> Возможно, Ваш аккаунт был ограничен по ошибке, сбою системы или неправдивому / необоснованному вынесению наказания. Приносим Наши извинения, желаем всего найлучшего!</i>")
        await state.finish()
        return
        
    except ValueError:
        await message.answer("❌ <b>Неверный формат ID.</b> <b>[Пример: 1234567890].</b>")
        await state.finish()
        return

@dp.callback_query_handler(lambda c: c.data == "statistics")
async def show_statistics(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    if user_id not in ADMIN_IDS:
        await bot.answer_callback_query(callback.id, text="🚫 У вас нет прав доступа.")
        return

    async with aiosqlite.connect(LOG_DB) as db:
        cursor = await db.execute("SELECT COUNT(*) FROM users")
        user_count = await cursor.fetchone()
        user_count = user_count[0] if user_count else 0
        cursor = await db.execute("SELECT COUNT(*) FROM users WHERE status = 1")
        blocked_count = await cursor.fetchone()
        blocked_count = blocked_count[0] if blocked_count else 0
        cursor = await db.execute("SELECT COUNT(*) FROM users WHERE status = 0")
        unblocked_count = await cursor.fetchone()
        unblocked_count = unblocked_count[0] if unblocked_count else 0

    keyboard = InlineKeyboardMarkup()
    keyboard.add(InlineKeyboardButton("❌ Закрыть", callback_data="close_statistics"))
    keyboard.add(InlineKeyboardButton("📂 Выгрузить ID пользователей", callback_data="export_user_ids"))
    
    await callback.message.answer(
        f"📊 <b>Всего пользователей: {user_count}</b>\n"
        f"❌ <b>Заблокировано пользователей: {blocked_count}</b>\n"
        f"✅ <b>Незаблокировано пользователей: {unblocked_count}</b>",
        reply_markup=keyboard
    )

@dp.callback_query_handler(lambda c: c.data == "export_user_ids")
async def export_user_ids(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    closeid = InlineKeyboardMarkup()
    closeid.add(InlineKeyboardButton("❌ Закрыть", callback_data="close_fileid"))
    if user_id not in ADMIN_IDS:
        await bot.answer_callback_query(callback.id, text="🚫 У вас нет прав доступа.")
        return

    if os.path.exists(USER_IDS_FILE):
        with open(USER_IDS_FILE, 'r') as file:
            file_content = file.read()

        file = InputFile(USER_IDS_FILE)
        capt = ("<b>📝 Список ID пользователей.</b>")
        await bot.send_document(chat_id=user_id, document=file, caption=capt, reply_markup=closeid)
    else:
        await callback.message.answer("❌ <b>Файл с ID пользователей не найден.</b>")

@dp.callback_query_handler(lambda c: c.data == "cancel_block")
async def cancel_block(callback: types.CallbackQuery):
    await callback.message.edit_text("🔴 <i><b>Действие заблокировать пользователя было отменено.</b></i>")

@dp.callback_query_handler(lambda c: c.data == "cancel_unblock")
async def cancel_unblock(callback: types.CallbackQuery):
    await callback.message.edit_text("🔴 <i><b>Действие разблокировать пользователя было отменено.</b></i>")

@dp.callback_query_handler(lambda c: c.data == "close_statistics")
async def close_statistics(callback: types.CallbackQuery):
    await callback.message.delete()

@dp.callback_query_handler(lambda c: c.data == "close_fileid")
async def close_statistics(callback: types.CallbackQuery):
    await callback.message.delete()

@dp.callback_query_handler(lambda c: c.data == 'send_message')
async def process_rassilka_callback(callback_query: types.CallbackQuery):
    user_id = callback_query.from_user.id
    if user_id not in ADMIN_IDS or user_id in [7203821059, 822551150]:
        await bot.answer_callback_query(callback_query.id, text="🚫 У вас нет прав доступа.")
        return

    cancel_button = InlineKeyboardButton("❌ Отменить", callback_data="cancel_rassilka")  
    keyboard = InlineKeyboardMarkup(row_width=1).add(cancel_button)  

    await bot.send_message(user_id, "📤 <b>Пожалуйста, отправьте сообщение для рассылки. Вы можете отправить текст или медиа с подписью.</b>", reply_markup=keyboard)  
    await Form.awaiting_rassilka.set()

@dp.message_handler(content_types=types.ContentTypes.ANY, state=Form.awaiting_rassilka)
async def handle_rassilka(message: types.Message, state: FSMContext):
    user_id = message.from_user.id
    if user_id not in ADMIN_IDS or user_id in [7203821059, 822551150]:
        await message.answer("🚫 <b>У вас нет прав доступа.</b>", parse_mode='HTML')
        return

    users = await load_user_ids()
    success_count = 0
    error_count = 0
    error_reports = []

    for target_user_id in users:
        try:
            if message.text:
                await bot.send_message(target_user_id, message.text, parse_mode='HTML')
                
            elif message.photo:
                caption = message.caption if message.caption else None
                await bot.send_photo(target_user_id, message.photo[-1].file_id, 
                                    caption=caption, parse_mode='HTML')
                
            elif message.video:
                caption = message.caption if message.caption else None
                await bot.send_video(target_user_id, message.video.file_id,
                                    caption=caption, parse_mode='HTML')
                
            elif message.audio:
                caption = message.caption if message.caption else None
                await bot.send_audio(target_user_id, message.audio.file_id,
                                   caption=caption, parse_mode='HTML')
                
            elif message.document:
                caption = message.caption if message.caption else None
                await bot.send_document(target_user_id, message.document.file_id,
                                      caption=caption, parse_mode='HTML')
                
            elif message.sticker:
                await bot.send_sticker(target_user_id, message.sticker.file_id)
                
            elif message.animation:
                caption = message.caption if message.caption else None
                await bot.send_animation(target_user_id, message.animation.file_id,
                                       caption=caption, parse_mode='HTML')
                
            elif message.voice:
                caption = message.caption if message.caption else None
                await bot.send_voice(target_user_id, message.voice.file_id,
                                   caption=caption, parse_mode='HTML')
                
            elif message.video_note:
                await bot.send_video_note(target_user_id, message.video_note.file_id)
                
            success_count += 1
            
        except Exception as e:
            error_count += 1
            error_reports.append(f"{target_user_id} - {str(e)}")
            logging.error(f"Ошибка отправки {target_user_id}: {e}")

    report = f"<b>📊 Итоги рассылки:</b>\n\n"
    report += f"✅ Успешно: {success_count}\n"
    report += f"❌ Ошибок: {error_count}\n"
    
    if error_count > 0:
        report += "\n<u>Примеры ошибок:</u>\n"
        for err in error_reports[-5:]:
            report += f"• {err}\n"

    await message.answer(report, parse_mode='HTML')
    users.clear()
    error_reports.clear()
    await state.finish()

@dp.callback_query_handler(lambda c: c.data == "cancel_rassilka")
async def cancel_rassilka(callback: types.CallbackQuery, state: FSMContext):
    user_id = callback.from_user.id
    if user_id not in ADMIN_IDS:
        await bot.answer_callback_query(callback.id, text="🚫 У вас нет прав доступа.")
        return

    await bot.edit_message_text("🚫 <i><b>Рассылка была отменена.</b></i>", callback.message.chat.id, callback.message.message_id)  
    await state.finish()

@dp.callback_query_handler(lambda c: c.data == "view_admins")
async def view_admins(callback: types.CallbackQuery):
    admin_list = []
    for idx, admin_id in enumerate(ADMIN_IDS, start=1):
        admin = await bot.get_chat(admin_id)
        username = f"@{admin.username}" if admin.username else f"<a href='tg://openmessage?user_id={admin_id}'>Администратор</a>"
        admin_list.append(f"{idx}. {admin_id} — {username}")
    
    admins_text = "👑 <b>Список Администраторов:</b>\n" + "\n".join(admin_list)
    keyboard = InlineKeyboardMarkup()
    keyboard.add(InlineKeyboardButton("📂 Выгрузить список администраторов", callback_data="export_admins"))
    keyboard.add(InlineKeyboardButton("❌ Закрыть", callback_data="close_admin_list"))
    
    await callback.message.edit_text(admins_text, reply_markup=keyboard, parse_mode="HTML")

@dp.callback_query_handler(lambda c: c.data == "export_admins")
async def export_admins(callback: types.CallbackQuery):
    admin_list = [f"{admin_id} — @{(await bot.get_chat(admin_id)).username}" if (await bot.get_chat(admin_id)).username else f"{admin_id} — {admin_id}" for admin_id in ADMIN_IDS]
    file_content = "\n".join(admin_list)
    file_path = "admins_list.txt"
    with open(file_path, "w", encoding="utf-8") as f:
        f.write(file_content)
    
    file = InputFile(file_path)
    keyboard = InlineKeyboardMarkup()
    keyboard.add(InlineKeyboardButton("❌ Закрыть", callback_data="close_file"))
    await bot.send_document(callback.from_user.id, file, caption="📂 <b>Список администраторов.</b>", reply_markup=keyboard, parse_mode="HTML")
    os.remove(file_path)

@dp.callback_query_handler(lambda c: c.data == "close_admin_list")
async def close_admin_list(callback: types.CallbackQuery):
    await callback.message.delete()

@dp.callback_query_handler(lambda c: c.data == "close_file")
async def close_file(callback: types.CallbackQuery):
    await callback.message.delete()
    
async def main():
    await init_db()
    print("БД Инициализирована.")
    logging.info("БД Инициализирована.")
    await init_pinned()
    print("БД Pinned Инициализирована.")
    logging.info("БД Pinned Инициализирована.")
    await dp.start_polling()

if __name__ == "__main__":
    asyncio.run(main())