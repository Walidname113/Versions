import csv
import json
import os
import time
import logging
import aiosqlite
from aiogram import Bot, Dispatcher, types, executor
import datetime
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, InputFile, ContentType
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from dotenv import load_dotenv
import asyncio
import sys
import nest_asyncio
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.dispatcher.filters import Text, ContentTypeFilter, Command
import subprocess
from aiogram.utils.callback_data import CallbackData
import aiogram
import re
from aiogram.utils.exceptions import BadRequest
from typing import List
from collections import defaultdict

@dp.callback_query_handler(lambda c: c.data == "players")
async def show_players_menu(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    if not await check_subscription(user_id):
        keyboard = InlineKeyboardMarkup().add(
            InlineKeyboardButton("✔️ Подписаться", url=f"https://t.me/{CHANNEL_ID.lstrip('@')}"),
            InlineKeyboardButton("✅️ Я подписался", callback_data="subscribed")
        )
        await callback.message.edit_text(
            "<i><b>⚠️ Извините, но обязательным условием бота является подписка на наш новостной канал. "
            "Вы не подписаны на канал — </b>@HaudDriblingChannel<b>. "
            "После подписки, нажмите на кнопку, чтобы использовать бота.</b></i>",
            reply_markup=keyboard
        )
        return

    players = load_players()
    keyboard = InlineKeyboardMarkup()

    for rank in players.keys():
        emoji = RANK_EMOJIS.get(rank, "")
        keyboard.add(InlineKeyboardButton(f"{emoji} Хаудфайтеры класса {rank}", callback_data=f"rankplayers_{rank}"))

    keyboard.add(InlineKeyboardButton("⬅ Назад", callback_data="back"))
    await safe_edit_text(callback.message, "⚜️ <b>Выберите ранг:</b>", keyboard)

@dp.callback_query_handler(lambda c: c.data.startswith("rankplayers_"))
async def show_players_by_rank(callback: types.CallbackQuery):
    rank = callback.data.split("_")[1]
    players = load_players().get(rank, [])
    emoji = RANK_EMOJIS.get(rank, "")
    if players:
        text = f"<blockquote><b>{emoji} Хаудфайтеры класса {rank}:</b></blockquote>\n" + "\n".join(f"{i+1}. {player}" for i, player in enumerate(players))
    else:
        text = "🚫 <b>Нет хаудфайтеров в этом классе.</b>"
    text += "\n\n<blockquote><b>❗️Нумерация — это не обозначение Хаудфайтера в топе класса, это просто нумерация, но в скором времени планируется доработка, следите за официальным источником.</b></blockquote>"

    keyboard = InlineKeyboardMarkup().add(InlineKeyboardButton("⬅ Назад", callback_data="players"))
    await callback.message.edit_text(text, reply_markup=keyboard)

def load_players():
    if not os.path.exists(DATA_DIR):
        os.makedirs(DATA_DIR)
    csv_mtime = os.path.getmtime(HAUDERS)
    players = {}
    if os.path.exists(PLAYERS_JSON):
        json_mtime = os.path.getmtime(PLAYERS_JSON)
        if csv_mtime > json_mtime:
            players = _load_players_from_csv()
            _save_players_to_json(players)
        else:
            with open(PLAYERS_JSON, "r", encoding="utf-8") as file:
                players = json.load(file)
    else:
        players = _load_players_from_csv()
        _save_players_to_json(players)

    return players

def _load_players_from_csv():
    players = {}
    with open(HAUDERS, "r", encoding="utf-8") as file:
        reader = csv.reader(file, delimiter=';')
        ranks = next(reader)
        names = next(reader)
        for rank, name_list in zip(ranks, names):
            players[rank] = name_list.split(", ") if name_list else []
    return players

def _save_players_to_json(players):
    with open(PLAYERS_JSON, "w", encoding="utf-8") as file:
        json.dump(players, file, ensure_ascii=False, indent=4)